<%@ include file="header.jsp" %>

<h2>Student Club Registration</h2>
<form action="processRegistration.jsp" method="POST">
    Student Name: <input type="text" name="studentName" required><br><br>
    Matric Number: <input type="text" name="matricNo" required><br><br>
    Selected Club: 
    <select name="club">
        <option value="Computer Science Club">Computer Science Club</option>
        <option value="Robotics Society">Robotics Society</option>
        <option value="Cyber Security Club">Cyber Security Club</option>
    </select><br><br>
    <input type="submit" value="Register">
</form>

<%@ include file="footer.jsp" %>