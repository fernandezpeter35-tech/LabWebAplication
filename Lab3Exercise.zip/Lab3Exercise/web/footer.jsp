<hr>
    <p style="text-align: center;">&copy; 2026 UMT Faculty of Computer Science and Mathematics</p>
</body>
</html>