<%@ page import="java.util.ArrayList" %>
<%@ include file="header.jsp" %>

<h2>Club Member Directory</h2>
<%
    ArrayList<String> committee = new ArrayList<String>();
    committee.add("Ahmad Zaki");
    committee.add("Siti Sarah");
    committee.add("Peter");
    committee.add("Lee Ming");
    committee.add("Nurul Huda");
%>

<table border="1" cellpadding="10">
    <tr style="background-color: #f2f2f2;">
        <th>Committee Member Name</th>
    </tr>
    <% for(String name : committee) { %>
    <tr>
        <td><%= name %></td>
    </tr>
    <% } %>
</table>

<%@ include file="footer.jsp" %>