<%@ include file="header.jsp" %>

<h2>Membership Fee Calculator</h2>
<form method="GET">
    Number of Activities Joined: 
    <input type="number" name="activityCount" min="0">
    <input type="submit" value="Calculate">
</form>

<%
    String countStr = request.getParameter("activityCount");
    if (countStr != null && !countStr.isEmpty()) {
        int count = Integer.parseInt(countStr);
        double totalFee = count * 10.0;
%>
    <h3>Total Fee: RM <%= String.format("%.2f", totalFee) %></h3>
<%
    }
%>

<%@ include file="footer.jsp" %>