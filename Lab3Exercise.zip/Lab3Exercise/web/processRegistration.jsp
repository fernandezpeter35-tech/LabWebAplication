<%@ include file="header.jsp" %>

<h2>Registration Confirmation</h2>
<p><strong>Name:</strong> <%= request.getParameter("studentName") %></p>
<p><strong>Matric Number:</strong> <%= request.getParameter("matricNo") %></p>
<p><strong>Club Joined:</strong> <%= request.getParameter("club") %></p>

<a href="registerClub.jsp">Back to Registration</a>

<%@ include file="footer.jsp" %>