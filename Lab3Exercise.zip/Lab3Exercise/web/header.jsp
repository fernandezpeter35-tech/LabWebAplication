<!DOCTYPE html>
<html>
<head>
    <title>Student Club System</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        nav { background: #006666; padding: 10px; }
        nav a { color: white; margin-right: 15px; text-decoration: none; }
    </style>
</head>
<body>
    <nav>
        <a href="registerClub.jsp">Registration Page</a>
        <a href="feeCalculator.jsp">Fee Calculator</a>
        <a href="memberDirectory.jsp">Club Member Directory</a>
    </nav>
    <hr>