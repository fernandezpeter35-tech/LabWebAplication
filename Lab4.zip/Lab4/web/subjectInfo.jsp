<%-- 
    Document   : subjectInfo
    Created on : 21 Apr 2026, 2:23:49 pm
    Author     : Peter
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<style>
    .info-card {
        background: white;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        max-width: 500px;
    }
    .info-card h2 {
        color: #7e57c2;
        font-weight: 500;
        margin-top: 0;
        margin-bottom: 25px;
    }
    .info-card p {
        margin: 12px 0;
        font-size: 14px;
        color: #444;
    }
    .label {
        font-weight: bold;
        color: #222;
    }
</style>

<div class="info-card">
    <h2>Calling SubjectInfo.Jsp Page</h2>
    
    <p><span class="label">Code:</span> <%= request.getParameter("code") %></p>
    <p><span class="label">Subject:</span> <%= request.getParameter("subject") %></p>
    <p><span class="label">Credit:</span> <%= request.getParameter("credit") %></p>
</div>