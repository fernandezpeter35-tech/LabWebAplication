<%-- 
    Document   : insuranceQuotation
    Created on : 21 Apr 2026, 2:55:55 pm
    Author     : Peter
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Insurance Quotation</title>
        <style>
            body { 
                font-family: Arial, sans-serif; 
                background-color: #f8f9fa; 
                display: flex; 
                justify-content: center; 
                padding-top: 50px;
            }
            .main-card { 
                background: white; 
                padding: 20px 40px 40px 40px; 
                border-radius: 8px; 
                width: 600px; 
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            }
            h2 { 
                color: #333; 
                font-size: 24px;
                border-left: 4px solid #6f42c1; /* Purple accent bar */
                padding-left: 15px;
                margin-bottom: 30px;
            }
            fieldset {
                border: 1px solid #ccc;
                border-radius: 4px;
                padding: 20px;
                margin-bottom: 20px;
            }
            legend {
                font-size: 0.95em;
                padding: 0 10px;
                color: #333;
            }
            .form-group { margin-bottom: 20px; }
            label { 
                display: block; 
                margin-bottom: 8px; 
                font-weight: bold; 
                font-size: 0.9em;
            }
            input, select { 
                width: 100%; 
                padding: 10px; 
                border: 1px solid #ddd; 
                border-radius: 4px; 
                box-sizing: border-box;
                color: #555;
            }
            input::placeholder { color: #ccc; }
            .btn-group { display: flex; gap: 10px; }
            button { 
                padding: 6px 12px; 
                border: 1px solid #aaa; 
                border-radius: 4px; 
                background: #efefef;
                cursor: pointer;
                font-size: 0.9em;
            }
            button:hover { background: #e5e5e5; }
        </style>
    </head>
    <body>
        <div class="main-card">
            <h2>Insurance Quotation</h2>
            
            <form action="processInsuranceQuo.jsp" method="POST">
                <fieldset>
                    <legend>Insurance Calculation</legend>
                    
                    <div class="form-group">
                        <label>IC No*</label>
                        <input type="text" name="icno" placeholder="E.g. 821210-05-3478" required>
                    </div>

                    <div class="form-group">
                        <label>Name*</label>
                        <input type="text" name="name" placeholder="Enter name" required>
                    </div>

                    <div class="form-group">
                        <label>Market Price*</label>
                        <input type="number" step="0.01" name="price" placeholder="Price" required>
                    </div>

                    <div class="form-group">
                        <label>Coverage Type</label>
                        <select name="coverage">
                            <option value="third_party">Third Party</option>
                            <option value="comprehensive">Comprehensive</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>No Claims Discount (NCD)</label>
                        <select name="ncd">
                            <option value="0.10">10%</option>
                            <option value="0.25">25%</option>
                            <option value="0.30">30%</option>
                            <option value="0.45">45%</option>
                            <option value="0.55">55%</option>
                        </select>
                    </div>

                    <div class="btn-group">
                        <button type="submit">Submit</button>
                        <button type="button" onclick="window.location.reload();">Cancel</button>
                    </div>
                </fieldset>
            </form>
        </div>
    </body>
</html>