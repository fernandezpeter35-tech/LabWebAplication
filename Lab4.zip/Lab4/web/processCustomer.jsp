<%-- 
    Document   : processCustomer
    Created on : 21 Apr 2026, 1:47:53 pm
    Author     : Peter
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Process Customer</title>
        <style>
            body { font-family: Arial, sans-serif; padding: 20px; line-height: 1.6; }
            .result-card { border: 1px solid #ddd; padding: 20px; border-radius: 8px; width: fit-content; }
            h2 { color: #8a2be2; }
            strong { color: #333; }
        </style>
    </head>
    <body>
        <%
            // 1. Fixed price
            final double price = 10.0;

            // 2. Retrieve form data using names from customer.html
            String cust_no = request.getParameter("custCode");
            String cust_type = request.getParameter("custType");
            
            int quantity = 0;
            try {
                quantity = Integer.parseInt(request.getParameter("quantity"));
            } catch (Exception e) {
                quantity = 0;
            }

            // 3. Business logic to calculate discount and total
            double total = 0;
            String message = "";

            if (cust_type.equals("1") && quantity > 100) {
                message = "You're entitled to 10% discount";
                total = quantity * price * 0.9;
            } 
            else if (cust_type.equals("2") && quantity > 100) {
                message = "You're entitled to 25% discount";
                total = quantity * price * 0.75;
            } 
            else {
                message = "You're not entitled to any discount";
                total = quantity * price;
            }

            // 4. Display customer type string
            String custTypeDisplay = cust_type.equals("1") ? "Normal Customer" : "Privilege Customer";
        %>

        <div class="result-card">
            <h2>Order Summary</h2>
            <p><strong>Customer Code:</strong> <%= cust_no %></p>
            <p><strong>Customer Type:</strong> <%= custTypeDisplay %></p>
            <p><strong>Quantity:</strong> <%= quantity %></p>
            <hr>
            <p><strong>Status:</strong> <%= message %></p>
            <p><strong>Total Amount:</strong> RM <%= String.format("%.2f", total) %></p>
            <br>
            <a href="customer.html">Back to Form</a>
        </div>
    </body>
</html>
