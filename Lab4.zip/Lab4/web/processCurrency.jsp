<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%! 
    final double USD = 0.25;
    final double EURO = 0.21;
    final double JPY = 40.0;
    final double SGD = 0.32;

    private double calculateRate(String currency, int amount) {
        if (currency == null) return 0.0;
        if (currency.equals("1")) return amount * USD;
        if (currency.equals("2")) return amount * EURO;
        if (currency.equals("3")) return amount * JPY;
        return amount * SGD;
    }
%>
<%
    String type = request.getParameter("currencyType");
    String rawAmt = request.getParameter("amount");
    int amount = (rawAmt != null) ? Integer.parseInt(rawAmt) : 0;
    double total = calculateRate(type, amount);

    String cName = "N/A";
    if ("1".equals(type)) cName = "USD";
    else if ("2".equals(type)) cName = "EURO";
    else if ("3".equals(type)) cName = "JPY";
    else if ("4".equals(type)) cName = "SGD";
%>
<!DOCTYPE html>
<html>
<head>
    <title>JSP Application Result</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f9f9f9; margin: 40px; }
        .header-title {
            border-left: 5px solid #6f42c1;
            padding-left: 15px;
            font-size: 24px;
            font-weight: bold;
            color: #333;
            margin-bottom: 30px;
        }
        .card {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
            max-width: 600px;
        }
        .card h2 { color: #6f42c1; margin-top: 0; font-size: 28px; margin-bottom: 25px; }
        .result-item { margin-bottom: 20px; }
        .label { display: block; font-weight: bold; color: #555; margin-bottom: 5px; }
        .value { display: block; font-size: 18px; color: #333; }
        button {
            background-color: #e0e0e0;
            border: 1px solid #ccc;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
        }
    </style>
</head>
<body>

    <div class="header-title">
        JSP Application Result
    </div>

    <div class="card">
        <h2>Conversion Result</h2>
        
        <div class="result-item">
            <span class="label">Amount in Ringgit Malaysia (RM):</span>
            <span class="value">RM <%= amount %></span>
        </div>

        <div class="result-item">
            <span class="label">Converted to (<%= cName %>):</span>
            <span class="value"><%= String.format("%.2f", total) %></span>
        </div>

        <button onclick="window.location.href='currencyConversion.html'">Back to Converter</button>
    </div>

</body>
</html>