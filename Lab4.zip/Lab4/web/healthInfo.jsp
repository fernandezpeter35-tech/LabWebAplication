<%-- 
    Document   : healthInfo
    Created on : 21 Apr 2026, 3:12:24?pm
    Author     : Peter
--%>

<%@page import="java.util.ArrayList"%>
<%@include file="header.jsp" %>
<h2>BMI Classification</h2>
<%
    ArrayList<String[]> data = new ArrayList<>();
    data.add(new String[]{"Under 18.5", "Underweight"});
    data.add(new String[]{"18.5 to 25.0", "Normal"});
    data.add(new String[]{"Above 25.0", "Overweight"});
%>
<table>
    <tr>
        <th>BMI Score</th>
        <th>Category</th>
    </tr>
    <% for(String[] item : data) { %>
    <tr>
        <td><%= item[0] %></td>
        <td><%= item[1] %></td>
    </tr>
    <% } %>
</table>
<%@include file="footer.jsp" %>