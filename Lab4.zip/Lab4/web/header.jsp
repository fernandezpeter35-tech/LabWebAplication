<%-- 
    Document   : header
    Created on : 21 Apr 2026, 3:06:44?pm
    Author     : Peter
--%>

<%-- header.jsp --%>
<!DOCTYPE html>
<html>
<head>
    <title>BMI Calculator</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f0f2f5; margin: 0; padding: 20px; color: #333; }
        .container { max-width: 800px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.1); }
        header { text-align: center; border-bottom: 2px solid #eee; margin-bottom: 25px; padding-bottom: 10px; }
        h1 { color: #2c3e50; font-size: 24px; }
        nav { background: #34495e; padding: 12px; border-radius: 8px; text-align: center; }
        nav a { color: #ecf0f1; text-decoration: none; margin: 0 15px; font-weight: 600; transition: color 0.3s; }
        nav a:hover { color: #3498db; }
        form { background: #f9f9f9; padding: 20px; border-radius: 8px; border: 1px solid #ddd; }
        label { display: block; margin-bottom: 8px; font-weight: bold; }
        input[type="number"] { width: 100%; padding: 10px; margin-bottom: 20px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { background: #27ae60; color: white; border: none; padding: 12px 25px; border-radius: 4px; cursor: pointer; font-size: 16px; width: 100%; }
        button:hover { background: #219150; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #34495e; color: white; }
        .result-box { background: #e8f8f5; border-left: 5px solid #27ae60; padding: 20px; margin-top: 20px; border-radius: 4px; }
    </style>
</head>
<body>
<div class="container">
    <header>
        <h1>BMI Calculator</h1>
        <nav>
            <a href="bmiCalculator.jsp">Home</a>
            <a href="healthInfo.jsp">Health Info</a>
        </nav>
    </header>