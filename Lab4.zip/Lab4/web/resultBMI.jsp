<%-- 
    Document   : resultBMI
    Created on : 21 Apr 2026, 3:11:58?pm
    Author     : Peter
--%>

<%@include file="header.jsp" %>
<h2>Your Result</h2>
<div class="result-box">
    <p style="font-size: 18px;">Calculated BMI: <strong style="color: #2c3e50;"><%= request.getParameter("bmiValue") %></strong></p>
    <p style="font-size: 18px;">Health Category: <strong style="color: #27ae60;"><%= request.getParameter("bmiCat") %></strong></p>
</div>
<p style="margin-top: 20px;"><a href="bmiCalculator.jsp" style="color: #3498db; text-decoration: none;">&larr; Start Over</a></p>

<%@include file="footer.jsp" %>