<%-- 
    Document   : footer.jsp
    Created on : 21 Apr 2026, 3:09:56?pm
    Author     : Peter
--%>

<%-- footer.jsp --%>
    <footer style="margin-top: 40px; text-align: center; font-size: 14px; color: #7f8c8d;">
        <hr style="border: 0; border-top: 1px solid #eee;">
        <p>&copy; 2026 UMT Faculty of Computer Science and Mathematics</p>
    </footer>
</div>
</body>
</html>