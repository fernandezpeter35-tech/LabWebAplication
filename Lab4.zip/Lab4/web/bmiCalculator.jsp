<%-- 
    Document   : bmiCalculator
    Created on : 21 Apr 2026, 3:10:47?pm
    Author     : Peter
--%>

<%@include file="header.jsp" %>
<h2>BMI Calculator</h2>
<p>Calculate your Body Mass Index instantly.</p>
<form action="processBMI.jsp" method="post">
    <label>Weight (kg):</label>
    <input type="number" step="0.01" name="weight" placeholder="e.g. 70.5" required>
    
    <label>Height (m):</label>
    <input type="number" step="0.01" name="height" placeholder="e.g. 1.75" required>
    
    <button type="submit">Calculate Now</button>
</form>
<%@include file="footer.jsp" %>