<%-- 
    Document   : processBMI
    Created on : 21 Apr 2026, 3:11:18?pm
    Author     : Peter
--%>

<%-- processBMI.jsp --%>
<%
    try {
        double weight = Double.parseDouble(request.getParameter("weight"));
        double height = Double.parseDouble(request.getParameter("height"));

        if (height <= 0) {
            out.println("<script>alert('Height cannot be zero!'); history.back();</script>");
        } else {
            double bmi = weight / (height * height);
            String category = (bmi < 18.5) ? "Underweight" : (bmi <= 25) ? "Normal" : "Overweight";
            String formattedBMI = String.format("%.2f", bmi);
%>
            <jsp:forward page="resultBMI.jsp">
                <jsp:param name="bmiValue" value="<%= formattedBMI %>" />
                <jsp:param name="bmiCat" value="<%= category %>" />
            </jsp:forward>
<%
        }
    } catch (Exception e) {
        out.println("<script>alert('Invalid input detected.'); history.back();</script>");
    }
%>