<%-- 
    Document   : forwardInfo
    Created on : 21 Apr 2026, 2:36:04 pm
    Author     : Peter
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Forwarded Information</title>
        <style>
            body {
                background-color: #f8f9fa;
                font-family: sans-serif; /* Clean, standard sans-serif */
                display: flex;
                flex-direction: column;
                align-items: center;
                padding-top: 50px;
                margin: 0;
            }

            .header-container {
                display: flex;
                align-items: center;
                width: 580px;
                margin-bottom: 25px;
                font-weight: bold;
                font-size: 22px;
                color: #333;
            }

            .purple-bar {
                width: 5px;
                height: 28px;
                background-color: #6f42c1;
                margin-right: 15px;
            }

            .card {
                background: white;
                width: 500px;
                padding: 45px;
                border-radius: 12px;
                box-shadow: 0 4px 20px rgba(0,0,0,0.06);
            }

            h2 {
                color: #8a2be2; /* The exact purple in your screenshot */
                font-size: 32px;
                margin-top: 0;
                margin-bottom: 35px; /* Large spacing after title */
                font-weight: 600;
            }

            .info-text {
                font-size: 18px;
                color: #000;
                margin-bottom: 22px; /* Specific spacing between rows */
                line-height: 1.2;
            }
        </style>
    </head>
    <body>

        <div class="header-container">
            <div class="purple-bar"></div>
            Using jsp:forward to display user info
        </div>

        <div class="card">
            <h2>Forwarded Info</h2>

            <%
                String name = request.getParameter("uname");
                String email = request.getParameter("email");
                String nationality = request.getParameter("nationality");
                String background = request.getParameter("background");
            %>

            <div class="info-text">Name: <%= (name != null) ? name : "" %></div>
            <div class="info-text">Email: <%= (email != null) ? email : "" %></div>
            <div class="info-text">Nationality: <%= (nationality != null) ? nationality : "" %></div>
            <div class="info-text">Background: <%= (background != null) ? background : "" %></div>
        </div>

    </body>
</html>