<%-- 
    Document   : jspParameter
    Created on : 21 Apr 2026, 2:20:11 pm
    Author     : Peter
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Using JSP Standard Action</title>
        <style>
            body {
                font-family: sans-serif;
                background-color: #f4f7f6;
                padding: 40px;
            }
            .header-container {
                border-left: 4px solid #673ab7;
                padding-left: 15px;
                margin-bottom: 20px;
            }
            h1 {
                font-size: 22px;
                color: #333;
                margin: 0;
            }
        </style>
    </head>
    <body>
        <div class="header-container">
            <h1>Using jsp:include and jsp:param to display information on JSP Page</h1>
        </div>

        <%
            String sCode = "CSE3023";
            String sSubject = "Web-based Application Development";
            String sCredit = "3(2+1)";
        %>

        <jsp:include page="subjectInfo.jsp" flush="true">
            <jsp:param name="code" value="<%= sCode %>" />
            <jsp:param name="subject" value="<%= sSubject %>" />
            <jsp:param name="credit" value="<%= sCredit %>" />
        </jsp:include>
    </body>
</html>