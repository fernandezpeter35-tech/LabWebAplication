<%-- 
    Document   : processInsuranceQuo
    Created on : 21 Apr 2026, 2:59:48 pm
    Author     : Peter
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    // Retrieve form data
    String icno = request.getParameter("icno");
    String name = request.getParameter("name");
    String coverage = request.getParameter("coverage");
    String ncdStr = request.getParameter("ncd");

    double price = 0;
    double ncd = 0;

    try {
        price = Double.parseDouble(request.getParameter("price"));
        ncd = Double.parseDouble(ncdStr);
    } catch (Exception e) {
        price = 0;
        ncd = 0;
    }

    // Business Logic
    double rate = 0;
    String coverageDisplay = "";

    if ("comprehensive".equals(coverage)) {
        rate = 0.05; // 5%
        coverageDisplay = "Comprehensive";
    } else {
        rate = 0.03; // 3%
        coverageDisplay = "Third Party";
    }

    // Base insurance calculation
    double insurance = price * rate;

    // Apply NCD discount
    double discount = insurance * ncd;
    double afterNCD = insurance - discount;

    // Add 8% SST
    double sst = afterNCD * 0.08;
    double finalAmount = afterNCD + sst;
%>

<!DOCTYPE html>
<html>
    <head>
        <title>Insurance Quotation Result</title>
        <style>
            body { font-family: sans-serif; background-color: #f4f7f6; padding: 20px; }
            .result-card {; background: white; padding: 30px; border-radius: 8px; max-width: 500px; margin: auto; box-shadow: 0 0 10px rgba(0,0,0,0.1); border-left: 5px solid #673ab7; }
            .label { color: #555; font-weight: bold; font-size: 0.9em; margin-top: 10px; }
            .value { margin-bottom: 10px; font-size: 1.1em; }
            .total { font-weight: bold; font-size: 1.3em; color: #000; border-top: 1px solid #ddd; padding-top: 10px; }
            hr { border: 0; border-top: 1px solid #eee; }
        </style>
    </head>
    <body>
        <div class="result-card">
            <h3>Insurance Quotation Result</h3>
            
            <div class="label">IC No:</div>
            <div class="value"><%= icno %></div>
            
            <div class="label">Name:</div>
            <div class="value"><%= name %></div>
            
            <div class="label">Market Price (RM):</div>
            <div class="value"><%= String.format("%.2f", price) %></div>
            
            <div class="label">Coverage Type:</div>
            <div class="value"><%= coverageDisplay %></div>
            
            <div class="label">NCD:</div>
            <div class="value"><%= (int)(ncd * 100) %>%</div>
            
            <hr>
            
            <div class="label">Base Insurance:</div>
            <div class="value">RM <%= String.format("%.2f", insurance) %></div>
            
            <div class="label">NCD Discount:</div>
            <div class="value">RM <%= String.format("%.2f", discount) %></div>
            
            <div class="label">After NCD:</div>
            <div class="value">RM <%= String.format("%.2f", afterNCD) %></div>
            
            <div class="label">SST (8%):</div>
            <div class="value">RM <%= String.format("%.2f", sst) %></div>
            
            <div class="total">Final Insurance Amount:</div>
            <div class="total">RM <%= String.format("%.2f", finalAmount) %></div>
            
            <br>
            <button onclick="window.history.back()">Back</button>
        </div>
    </body>
</html>
